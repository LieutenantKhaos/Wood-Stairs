Wood Stairs - Bark Risers resource pack

Requires WoodStairs-plank-steps.jar.
Bark on vertical risers; plank tops and bottoms. All 26 woods, all shapes and upside-down placements.
BOP woods require Biomes O Plenty.

Copy this ZIP into Minecraft resourcepacks, enable in Options > Resource Packs, and place above other Wood Stairs packs.
Keep the mod JAR in mods. Disable this pack to restore plank risers.

Minecraft 26.2 / resource pack format 88.0.